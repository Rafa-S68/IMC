package com.example.viacepapi

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cep")
data class CepEntity(
    @PrimaryKey val cep: String,
    val logradouro: String,
    val bairro: String,
    val localidade: String,
    val uf: String
)
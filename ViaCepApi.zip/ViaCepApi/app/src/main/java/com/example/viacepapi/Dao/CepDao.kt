package com.example.viacepapi

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface CepDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun inserir(cepEntity: CepEntity)

    @Query("SELECT * FROM cep WHERE cep = :cep")
    suspend fun buscarCep(cep: String): CepEntity?
}

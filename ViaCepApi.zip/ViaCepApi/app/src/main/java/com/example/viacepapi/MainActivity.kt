package com.example.viacepapi

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.viacepapi.Dao.ViaCepApi
import com.example.viacepapi.AppDatabase
import com.example.viacepapi.CepEntity
import com.example.viacepapi.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var api: ViaCepApi
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        db = AppDatabase.getInstance(this)


        api = Retrofit.Builder()
            .baseUrl("https://viacep.com.br/ws/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ViaCepApi::class.java)


        binding.btBuscarCep.setOnClickListener {
            val cep = binding.editCep.text.toString().trim()

            if (isValidCep(cep)) {
                binding.cepLayout.error = null
                buscarECadastrarCep(cep)
            } else {
                binding.cepLayout.error = "CEP inválido! Digite um CEP com 8 dígitos."
            }
        }


        binding.btLimpar.setOnClickListener {
            limparCampos()
        }
    }


    private fun isValidCep(cep: String): Boolean {
        return cep.matches(Regex("^\\d{8}\$"))
    }


    private fun limparCampos() {

        binding.run {
            editCep.setText("")
            editLogradouro.setText("")
            editBairro.setText("")
            editCidade.setText("")
            editEstado.setText("")
        }
        binding.cepLayout.error = null
    }


    private fun buscarECadastrarCep(cep: String) {
        lifecycleScope.launch {
            try {
                val resultado = withContext(Dispatchers.IO) {
                    api.buscarCep(cep)
                }


                if (resultado.cep.isNullOrEmpty()) {
                    withContext(Dispatchers.Main) {
                        binding.cepLayout.error = "CEP não encontrado!"
                        Toast.makeText(this@MainActivity, "CEP não encontrado!", Toast.LENGTH_SHORT).show()
                    }
                } else {

                    binding.editLogradouro.setText(resultado.logradouro ?: "")
                    binding.editBairro.setText(resultado.bairro ?: "")
                    binding.editCidade.setText(resultado.localidade ?: "")
                    binding.editEstado.setText(resultado.uf ?: "")


                    val cepEntity = CepEntity(
                        cep = resultado.cep ?: "",
                        logradouro = resultado.logradouro ?: "",
                        bairro = resultado.bairro ?: "",
                        localidade = resultado.localidade ?: "",
                        uf = resultado.uf ?: ""
                    )


                    withContext(Dispatchers.IO) {
                        db.cepDao().inserir(cepEntity)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    binding.cepLayout.error = "Erro ao buscar CEP"
                    Toast.makeText(this@MainActivity, "Erro ao buscar CEP", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}

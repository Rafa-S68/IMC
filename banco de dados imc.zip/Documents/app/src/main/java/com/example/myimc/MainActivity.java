package com.example.myimc;

import android.app.Activity;

public class MainActivity extends Activity {
}

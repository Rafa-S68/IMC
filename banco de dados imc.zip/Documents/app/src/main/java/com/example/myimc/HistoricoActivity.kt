import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.myimc.AppDatabase
import com.example.myimc.R
import com.example.myimc.dao.UsuarioDao

class HistoricoActivity : AppCompatActivity() {

    private lateinit var usuarioDao: UsuarioDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_historico)

        val db = AppDatabase.getInstance(this)
        usuarioDao = db.usuarioDao()

        val listaUsuarios = usuarioDao.getTodos()

        val textView = findViewById<TextView>(R.id.txtHistorico)
        textView.text = listaUsuarios.joinToString(separator = "\n") {
            "${it.nome} ${it.sobrenome} - ${it.idade} anos - ${it.celular}"
        }

    }
    }

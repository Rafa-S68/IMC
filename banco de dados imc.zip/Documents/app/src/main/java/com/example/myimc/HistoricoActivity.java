package com.example.myimc;

import android.app.Activity;

public class HistoricoActivity extends Activity {
}

package com.example.myimc.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.myimc.model.Usuario

@Dao
interface UsuarioDao {

    @Insert
    fun inserir(listaUsuarios: MutableList<Usuario>)

    @Query("SELECT * FROM tabela_usuarios")
    fun getTodos(): List<Usuario>
}
